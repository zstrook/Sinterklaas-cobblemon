SINTERKLAAS - Cobblemon / Cobbleverse addon
============================================
One pack, works as BOTH a resource pack and a data pack.

INSTALL (singleplayer)
 1. Resource pack: put the ZIP (unextracted) in  .minecraft/resourcepacks  (for Cobbleverse via
    Prism/Modrinth: instances/<pack>/minecraft/resourcepacks) and enable it in Options > Resource Packs.
 2. Data pack: put the SAME ZIP in  saves/<your world>/datapacks  then run /reload
    (or drop it in before opening the world).
 3. Test:  /spawnpokemon sinterklaas level=50      (shiny: /spawnpokemon sinterklaas shiny level=50)
    Give:  /givepokemon @s sinterklaas level=50

SERVER: ZIP goes in world/datapacks on the server; every player needs it as a resource pack.

CONTENTS
 assets/cobblemon/bedrock/pokemon/models/sinterklaas/sinterklaas.geo.json
 assets/cobblemon/bedrock/pokemon/animations/sinterklaas/sinterklaas.animation.json   (ground_idle, ground_walk)
 assets/cobblemon/bedrock/pokemon/posers/sinterklaas/sinterklaas.json
 assets/cobblemon/bedrock/pokemon/resolvers/sinterklaas/  (base + shiny)
 assets/cobblemon/textures/pokemon/sinterklaas/sinterklaas.png  + sinterklaas_shiny.png
 assets/cobblemon/lang/en_us.json, nl_nl.json
 data/cobblemon/species/custom/sinterklaas.json
 data/cobblemon/spawn_pool_world/sinterklaas.json   (rare, snowy biomes)
 blockbench/sinterklaas.bbmodel   <- open in Blockbench to edit; export Bedrock Entity geo to update

TWEAKS
 - Portrait/summary framing: portraitScale / portraitTranslation / profileScale in the poser json.
 - Spawn biomes/rarity: spawn_pool_world/sinterklaas.json
 - Dex number 99001 is arbitrary; change if it clashes with another addon.
